@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; try { $r=Invoke-RestMethod -Uri 'https://api.github.com/repos/nikotonic/Nwa/releases/tags/auditoria-qa-proton-local-v1.0.0'; $m=[regex]::Match($r.body,'(?s)PROTON_CONFIG_START\r?\n(.*?)\r?\nPROTON_CONFIG_END'); if (-not $m.Success) { throw 'La configuracion ya no esta publicada. Usa tu archivo Proton original.' }; $p=Join-Path (Get-Location) 'QA-Proton.conf'; [IO.File]::WriteAllText($p,$m.Groups[1].Value+[Environment]::NewLine,(New-Object Text.UTF8Encoding($false))); Write-Host 'Listo: QA-Proton.conf. Importalo y activalo en WireGuard.' } catch { Write-Host $_.Exception.Message; exit 1 }"
echo.
pause
endlocal
