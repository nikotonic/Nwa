#!/usr/bin/env python3
# Auditoría de solo lectura para una instancia QA autorizada.
# Una única solicitud GET anónima a una URL fija.
# No guarda el HTML, no envía credenciales y no sigue redirecciones.

from __future__ import annotations

import csv
import os
from vpn_local import vpn_opener
import hashlib
import json
import re
import sys
import unicodedata
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import (
    HTTPRedirectHandler,
    ProxyHandler,
    Request,
    build_opener,
)

TARGET_URL = (
    "http://187.179.151.80/Comercial/Utils/Browse.aspx"
    "?intEmpresa=2&intSucursal=7&classname=DACProspecto"
    "&parametro0=QA-Prospecto-001&version=19&parametros=1"
    "&buscarpor=strNombre&IsQuery=1"
)
TARGET_IP = "187.179.151.80"

TIMEOUT_SECONDS = 60
MAX_RESPONSE_BYTES = 10 * 1024 * 1024
DEFAULT_MAX_RECORDS = 100
ABSOLUTE_MAX_RECORDS = 1000

EMAIL_RE = re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.I)
PHONE_RE = re.compile(r"\+?\d[\d\s().-]{5,}\d")

EMAIL_HEADERS = (
    "email", "e-mail", "correo", "mail"
)
PHONE_HEADERS = (
    "telefono", "celular", "movil", "phone", "mobile",
    "numero telefonico", "num telefono"
)


def normalize_label(value: str) -> str:
    value = unicodedata.normalize("NFKD", value or "")
    value = "".join(c for c in value if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", value).strip().lower()


def identify_contact_column(header: str) -> str | None:
    label = normalize_label(header)
    if any(word in label for word in EMAIL_HEADERS):
        return "email"
    if any(word in label for word in PHONE_HEADERS):
        return "phone"
    return None


class HTMLTableParser(HTMLParser):
    """Lee únicamente filas/celdas de tablas HTML; no ejecuta scripts."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables: list[list[list[str]]] = []
        self.table_depth = 0
        self.current_table: list[list[str]] | None = None
        self.current_row: list[str] | None = None
        self.current_cell: list[str] | None = None

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()

        if tag == "table":
            self.table_depth += 1
            if self.table_depth == 1:
                self.current_table = []
            return

        if self.table_depth != 1:
            return

        if tag == "tr":
            self.current_row = []
        elif tag in ("td", "th") and self.current_row is not None:
            self.current_cell = []
        elif tag == "br" and self.current_cell is not None:
            self.current_cell.append(" ")

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_data(self, data):
        if self.table_depth == 1 and self.current_cell is not None:
            self.current_cell.append(data)

    def handle_endtag(self, tag):
        tag = tag.lower()

        if tag in ("td", "th") and self.table_depth == 1:
            if self.current_row is not None and self.current_cell is not None:
                cell = " ".join("".join(self.current_cell).split())
                self.current_row.append(cell)
            self.current_cell = None
            return

        if tag == "tr" and self.table_depth == 1:
            if self.current_row is not None:
                if self.current_cell is not None:
                    cell = " ".join("".join(self.current_cell).split())
                    self.current_row.append(cell)
                if self.current_row:
                    self.current_table.append(self.current_row)
            self.current_row = None
            self.current_cell = None
            return

        if tag == "table" and self.table_depth > 0:
            self.table_depth -= 1
            if self.table_depth == 0 and self.current_table is not None:
                self.tables.append(self.current_table)
                self.current_table = None
                self.current_row = None
                self.current_cell = None


class NoRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def choose_contact_table(tables):
    """Elige la tabla con más encabezados de contacto reconocibles."""
    best = None
    best_score = 0

    for table in tables:
        for row_index, row in enumerate(table):
            columns = {}
            for col_index, cell in enumerate(row):
                kind = identify_contact_column(cell)
                if kind and kind not in columns:
                    columns[kind] = col_index

            score = len(columns)
            if score > best_score:
                best = (table, row_index, columns)
                best_score = score
            if score == 2:
                return best

    return best


def first_email(value: str) -> str:
    match = EMAIL_RE.search(value or "")
    return match.group(0).strip() if match else ""


def first_phone(value: str) -> str:
    for candidate in PHONE_RE.findall(value or ""):
        candidate = candidate.strip()
        digits = re.sub(r"\D", "", candidate)
        if 7 <= len(digits) <= 15:
            return ("+" if candidate.startswith("+") else "") + digits
    return ""


def extract_contact_pairs(html: str, max_records: int):
    parser = HTMLTableParser()
    parser.feed(html)

    selected = choose_contact_table(parser.tables)
    if not selected:
        return {
            "header_found": False,
            "columns": [],
            "rows_processed": 0,
            "pairs": [],
        }

    table, header_index, columns = selected
    email_col = columns.get("email")
    phone_col = columns.get("phone")

    pairs = []
    seen_pairs = set()
    rows_processed = 0

    for row in table[header_index + 1:]:
        if rows_processed >= max_records:
            break
        if not any(str(cell).strip() for cell in row):
            continue

        # Ignorar encabezados repetidos de la grilla.
        if any(identify_contact_column(cell) for cell in row):
            continue

        rows_processed += 1

        email = ""
        phone = ""

        if email_col is not None and email_col < len(row):
            email = first_email(row[email_col])

        if phone_col is not None and phone_col < len(row):
            phone = first_phone(row[phone_col])

        if not email and not phone:
            continue

        # Deduplicar la pareja exacta preserva la relación correo-teléfono.
        # Si un correo aparece con dos teléfonos distintos, ambas relaciones
        # se conservan en lugar de emparejar datos de filas diferentes.
        key = (email.casefold(), phone)
        if key not in seen_pairs:
            seen_pairs.add(key)
            pairs.append((email, phone))

    return {
        "header_found": True,
        "columns": list(columns.keys()),
        "rows_processed": rows_processed,
        "pairs": pairs,
    }


def write_csv(path: Path, pairs):
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle)
        writer.writerow(["correo_sintetico", "telefono_sintetico"])
        writer.writerows(pairs)


def ask_max_records() -> int:
    raw = input(f"Máximo de registros a procesar [{DEFAULT_MAX_RECORDS}]: ").strip()
    if not raw:
        return DEFAULT_MAX_RECORDS

    try:
        value = int(raw)
    except ValueError:
        raise ValueError("Debes escribir un número entero.")

    if not 1 <= value <= ABSOLUTE_MAX_RECORDS:
        raise ValueError(
            f"El límite permitido es de 1 a {ABSOLUTE_MAX_RECORDS} registros."
        )
    return value


def main(max_records=DEFAULT_MAX_RECORDS, output_dir=None) -> int:
    output_dir = Path(output_dir or Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "AuditoriaQA" / "resultados")
    output_dir.mkdir(parents=True, exist_ok=True)
    if not 1 <= max_records <= ABSOLUTE_MAX_RECORDS:
        raise ValueError("El limite debe estar entre 1 y 1000.")
    generated_at = datetime.now(timezone.utc).isoformat()

    print("=" * 68)
    print("AUDITORÍA QA DE SOLO LECTURA")
    print("=" * 68)
    print(f"Destino fijo: {TARGET_IP}")
    print("Método: una única solicitud GET anónima.")
    print("No se enviarán credenciales, cookies, tokens ni encabezados de sesión.")
    print("No se seguirán redirecciones ni se probarán otras rutas.")
    print()
    print("Salida obligatoria: tunel Proton local QA-Proton.")
    print("Sin conexion directa de respaldo.")

    request = Request(
        TARGET_URL,
        headers={
            "User-Agent": "Authorized-QA-ReadOnly-Audit/1.0",
            "Accept": "text/html,application/xhtml+xml",
        },
        method="GET",
    )

    opener, tunnel = vpn_opener(TARGET_URL, TARGET_IP, NoRedirectHandler())

    started = datetime.now(timezone.utc)
    status = None
    response_headers = {}
    body = b""
    error = None
    too_large = False

    try:
        with opener.open(request, timeout=TIMEOUT_SECONDS) as response:
            status = response.status
            response_headers = {
                "content_type": response.headers.get("Content-Type", ""),
                "content_length": response.headers.get("Content-Length", ""),
            }
            body = response.read(MAX_RESPONSE_BYTES + 1)
    except HTTPError as exc:
        status = exc.code
        response_headers = {
            "content_type": exc.headers.get("Content-Type", "") if exc.headers else "",
            "content_length": exc.headers.get("Content-Length", "") if exc.headers else "",
        }
        # No se analiza contenido de respuestas de error ni redirecciones.
        error = f"HTTP {exc.code}"
        try:
            body = exc.read(MAX_RESPONSE_BYTES + 1)
        except Exception:
            body = b""
    except (URLError, TimeoutError, OSError) as exc:
        error = f"{type(exc).__name__}: {exc}"

    finished = datetime.now(timezone.utc)
    duration_ms = int((finished - started).total_seconds() * 1000)

    if len(body) > MAX_RESPONSE_BYTES:
        too_large = True
        body = body[:MAX_RESPONSE_BYTES]

    response_hash = hashlib.sha256(body).hexdigest() if body else None
    pairs = []
    extraction = {
        "header_found": False,
        "columns": [],
        "rows_processed": 0,
        "pairs": [],
    }

    if status == 200 and body and not too_large:
        content_type = response_headers.get("content_type", "")
        charset_match = re.search(r"charset=([\w.-]+)", content_type, re.I)
        charset = charset_match.group(1) if charset_match else "utf-8"
        try:
            html = body.decode(charset, errors="replace")
        except LookupError:
            html = body.decode("utf-8", errors="replace")
        extraction = extract_contact_pairs(html, max_records)
        pairs = extraction["pairs"]

    csv_path = output_dir / "contactos_qa.csv"
    evidence_path = output_dir / "evidencia_qa.json"
    report_path = output_dir / "informe_qa.md"

    write_csv(csv_path, pairs)

    evidence = {
        "generated_at_utc": generated_at,
        "target_url": TARGET_URL,
        "target_ip": TARGET_IP,
        "method": "GET",
        "authentication_context": "anonymous",
        "cookies_sent": False,
        "authorization_header_sent": False,
        "redirects_followed": False,
        "other_routes_tested": False,
        "parameters_modified": False,
        "pagination_used": False,
        "max_records_requested": max_records,
        "vpn": {
            "mode": "local_wireguard_interface_pinned",
            "interface": tunnel.name,
            "interface_index": tunnel.index,
            "source_ip": tunnel.ip,
            "interface_verified_before_request": True,
            "direct_fallback": False,
            "public_exit_ip_verified": False,
            "verification_note": "Socket fijado a la interfaz WireGuard y a su IPv4 local. La identidad de salida publica no se consulta a servicios externos.",
        },
        "http_status": status,
        "duration_ms": duration_ms,
        "response_bytes_read": len(body),
        "response_sha256_of_bytes_read": response_hash,
        "response_truncated": too_large,
        "response_headers_recorded": response_headers,
        "recognized_contact_columns": extraction["columns"],
        "contact_header_found": extraction["header_found"],
        "data_rows_processed": extraction["rows_processed"],
        "unique_contact_pairs": len(pairs),
        "raw_html_saved": False,
        "credentials_or_cookies_saved": False,
        "error": error,
    }

    evidence_path.write_text(
        json.dumps(evidence, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    report = [
        "# Informe de auditoría — instancia QA",
        "",
        f"- Fecha UTC: {generated_at}",
        f"- URL: `{TARGET_URL}`",
        "- Contexto: GET anónimo, sin cookies ni credenciales.",
        f"- Destino: `{TARGET_IP}`",
        "- Ruta: interfaz WireGuard local QA-Proton; socket fijado a su indice e IPv4.",
        f"- Estado HTTP: `{status if status is not None else 'sin respuesta'}`",
        f"- Duración: {duration_ms} ms",
        f"- Filas procesadas: {extraction['rows_processed']}",
        f"- Parejas únicas correo/teléfono: {len(pairs)}",
        "",
        "## Resultado",
    ]

    if error:
        report.append(f"- La solicitud no se completó: {error}.")
    elif too_large:
        report.append(
            f"- La respuesta superó el límite de {MAX_RESPONSE_BYTES} bytes. "
            "No se analizaron contactos."
        )
    elif status != 200:
        report.append(
            "- No se analizaron contactos porque la respuesta no fue HTTP 200. "
            "No se siguieron redirecciones."
        )
    elif not extraction["header_found"]:
        report.append(
            "- No se encontraron encabezados explícitos de correo/teléfono. "
            "No se intentó inferir información por el contenido de las celdas."
        )
    elif pairs:
        report.append(
            "- Se detectaron valores bajo encabezados reconocibles en una "
            "respuesta anónima de la instancia QA."
        )
        report.append(
            "- Hallazgo confirmado únicamente para esta URL y esta instancia QA. "
            "La severidad en producción queda pendiente de comprobar con "
            "autorización y evidencia independiente."
        )
    else:
        report.append(
            "- Se reconocieron encabezados de contacto, pero no se extrajeron "
            "valores en las filas procesadas."
        )

    report.extend([
        "",
        "## Alcance y limitaciones",
        "- Una sola solicitud GET; sin POST, callbacks, redirecciones, "
        "paginación, enumeración ni modificación de parámetros.",
        "- No se guardó el HTML original.",
        "- El cliente fija el socket al tunel local. Comprobar la IP de salida Proton "
        "de origen en los logs del servidor QA.",
        "- HTTP no cifra el tramo desde el servidor VPN hasta el servidor QA. "
        "La VPN no sustituye HTTPS.",
        "- No se realizó prueba autenticada; no enviar credenciales por HTTP.",
        "",
        "## Recomendaciones",
        "- Exigir autenticación y autorización en el servidor antes de devolver "
        "datos de contacto.",
        "- Aplicar permisos por empresa, sucursal y columna en el backend.",
        "- No depender del ocultamiento de columnas en el navegador.",
        "- Habilitar HTTPS y revisar los registros de acceso.",
        "",
        "## Archivos generados",
        "- `contactos_qa.csv`: parejas de contacto deduplicadas.",
        "- `evidencia_qa.json`: metadatos y SHA-256 de los bytes leídos.",
        "- `informe_qa.md`: este informe.",
        "",
    ])
    report_path.write_text("\n".join(report), encoding="utf-8")

    print()
    print("Auditoría terminada.")
    print(f"Estado HTTP: {status if status is not None else 'sin respuesta'}")
    print(f"Parejas únicas detectadas: {len(pairs)}")
    print(f"CSV: {csv_path}")
    print(f"Evidencia: {evidence_path}")
    print(f"Informe: {report_path}")
    print("El HTML original no se guardó.")
    return 1 if error or too_large or status != 200 else 0


if __name__ == "__main__":
    raise SystemExit("Abre AuditoriaQA.exe o ejecuta app_windows.py.")
