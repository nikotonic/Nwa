"""Auditoria manual en Windows, con conexion fijada al tunel Proton local."""
import contextlib
import io
import os
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import messagebox, ttk

from auditar_qa_vpn import main, TARGET_IP

BASE = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'AuditoriaQAProton'
RESULTS = BASE / 'resultados'


class App:
    def __init__(self, root):
        self.root = root
        self.events = queue.Queue()
        self.busy = False
        root.title('Auditoria QA — Proton VPN local')
        root.geometry('790x590')
        root.minsize(700, 520)
        root.protocol('WM_DELETE_WINDOW', self.close)
        frame = ttk.Frame(root, padding=20)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text='Auditoria con Proton VPN', font=('Segoe UI', 19, 'bold')).pack(anchor='w')
        ttk.Label(frame, text=f'Destino: {TARGET_IP} | Una consulta por pulsacion', font=('Segoe UI', 10)).pack(anchor='w', pady=(6, 14))
        ttk.Label(frame, wraplength=730, text='1. Importa QA-Proton.conf en WireGuard para Windows.\n2. Activa el tunel QA-Proton.\n3. Pulsa Ejecutar cuando quieras consultar.').pack(anchor='w')
        ttk.Button(frame, text='Abrir WireGuard', command=self.open_wireguard).pack(anchor='w', pady=10)
        ttk.Label(frame, wraplength=730, text='Solo el destino de la auditoria pasa por este tunel. Sin VPN activa, la consulta se bloquea. No hay consultas programadas ni reintentos automaticos.').pack(anchor='w')
        row = ttk.Frame(frame)
        row.pack(fill='x', pady=12)
        ttk.Label(row, text='Maximo de filas (1–1000):').pack(side='left')
        self.limit = tk.StringVar(value='100')
        self.spin = ttk.Spinbox(row, from_=1, to=1000, textvariable=self.limit, width=8)
        self.spin.pack(side='left', padx=8)
        self.authorized = tk.BooleanVar(value=False)
        ttk.Checkbutton(frame, text='Confirmo el alcance autorizado de la instancia QA y sus datos sinteticos.', variable=self.authorized).pack(anchor='w')
        buttons = ttk.Frame(frame)
        buttons.pack(fill='x', pady=12)
        self.run_button = ttk.Button(buttons, text='Ejecutar consulta por VPN', command=self.run)
        self.run_button.pack(side='left')
        ttk.Button(buttons, text='Abrir resultados', command=self.open_results).pack(side='left', padx=8)
        self.status = tk.StringVar(value='En espera. No se han realizado consultas.')
        ttk.Label(frame, textvariable=self.status, wraplength=730).pack(anchor='w', pady=4)
        self.log = tk.Text(frame, height=10, wrap='word', state='disabled')
        self.log.pack(fill='both', expand=True)
        root.after(100, self.poll)

    def close(self):
        if self.busy:
            messagebox.showinfo('Consulta en curso', 'Espera a que termine la consulta o su tiempo de espera.')
            return
        self.root.destroy()

    def open_wireguard(self):
        path = Path(os.environ.get('ProgramFiles', r'C:\Program Files')) / 'WireGuard' / 'wireguard.exe'
        try:
            if not path.is_file():
                raise OSError('Instala WireGuard para Windows desde https://www.wireguard.com/install/ y luego importa QA-Proton.conf.')
            os.startfile(str(path))
        except OSError as exc:
            messagebox.showinfo('WireGuard', str(exc))

    def open_results(self):
        try:
            RESULTS.mkdir(parents=True, exist_ok=True)
            os.startfile(str(RESULTS))
        except OSError as exc:
            messagebox.showerror('Resultados', str(exc))

    def run(self):
        if self.busy:
            return
        try:
            limit = int(self.limit.get())
            if not 1 <= limit <= 1000:
                raise ValueError('El limite debe estar entre 1 y 1000.')
            if not self.authorized.get():
                raise ValueError('Confirma el alcance autorizado antes de ejecutar.')
        except ValueError as exc:
            messagebox.showerror('Revisar datos', str(exc))
            return
        self.busy = True
        self.run_button.configure(state='disabled')
        self.spin.configure(state='disabled')
        self.status.set('Comprobando el tunel local y ejecutando una consulta...')
        threading.Thread(target=self.worker, args=(limit,), daemon=True).start()

    def worker(self, limit):
        output = io.StringIO()
        try:
            with contextlib.redirect_stdout(output):
                code = main(limit, RESULTS)
            self.events.put((code, output.getvalue()))
        except Exception as exc:
            self.events.put((1, output.getvalue() + '\nError: ' + str(exc)))

    def poll(self):
        # Este temporizador solo actualiza la ventana; no consulta la red.
        try:
            code, output = self.events.get_nowait()
        except queue.Empty:
            pass
        else:
            self.log.configure(state='normal')
            self.log.delete('1.0', 'end')
            self.log.insert('end', output)
            self.log.configure(state='disabled')
            self.status.set('Consulta terminada. En espera de otra pulsacion.' if code == 0 else 'Consulta bloqueada o fallida. Revisa el registro. No se reintentara.')
            self.busy = False
            self.run_button.configure(state='normal')
            self.spin.configure(state='normal')
        self.root.after(100, self.poll)


def start():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == '__main__':
    start()
