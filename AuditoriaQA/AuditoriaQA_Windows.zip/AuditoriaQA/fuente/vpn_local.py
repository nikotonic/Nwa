"""HTTP exclusivamente por una interfaz WireGuard local de Windows."""
from dataclasses import dataclass
import http.client
import ipaddress
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
from urllib.request import HTTPHandler, ProxyHandler, build_opener

TUNNEL_NAME = 'QA-Proton'
EXPECTED_IPV4 = '10.2.0.2'

@dataclass(frozen=True)
class Tunnel:
    index: int
    ip: str
    name: str


def read_tunnel():
    if os.name != 'nt':
        raise OSError('Esta aplicacion requiere Windows 10/11.')
    shell = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32' / 'WindowsPowerShell' / 'v1.0' / 'powershell.exe'
    command = r'''
$ErrorActionPreference='Stop'
$a=@(Get-NetAdapter -IncludeHidden | Where-Object {
    $_.Name -eq $env:QA_TUNNEL_NAME -and $_.Status -eq 'Up' -and
    $_.InterfaceDescription -like '*WireGuard*'
})
if ($a.Count -ne 1) { throw 'Activa el tunel QA-Proton en WireGuard antes de consultar.' }
$n=@(Get-NetIPInterface -InterfaceIndex $a[0].ifIndex -AddressFamily IPv4)
if ($n.Count -ne 1 -or $n[0].WeakHostSend -ne 'Disabled') {
    throw 'La interfaz requiere WeakHostSend desactivado; consulta bloqueada.'
}
$ip=@(Get-NetIPAddress -InterfaceIndex $a[0].ifIndex -AddressFamily IPv4 |
    Where-Object { $_.AddressState -eq 'Preferred' -and $_.IPAddress -eq $env:QA_TUNNEL_IP })
if ($ip.Count -ne 1) { throw 'La IPv4 del tunel no coincide con la configuracion Proton suministrada.' }
@{index=[int]$a[0].ifIndex; ip=$ip[0].IPAddress; name=$a[0].Name} | ConvertTo-Json -Compress
'''
    try:
        result = subprocess.run(
            [str(shell), '-NoProfile', '-NonInteractive', '-Command', command],
            env=dict(os.environ, QA_TUNNEL_NAME=TUNNEL_NAME, QA_TUNNEL_IP=EXPECTED_IPV4),
            capture_output=True, text=True, timeout=20, check=True,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
        data = json.loads(result.stdout)
        tunnel = Tunnel(int(data['index']), str(data['ip']), str(data['name']))
        if tunnel.index <= 0 or tunnel.ip != EXPECTED_IPV4 or tunnel.name != TUNNEL_NAME:
            raise ValueError('Datos de interfaz inesperados.')
        ipaddress.IPv4Address(tunnel.ip)
        return tunnel
    except (subprocess.SubprocessError, ValueError, KeyError, OSError) as exc:
        raise OSError('VPN no disponible o interfaz no valida. Activa QA-Proton en WireGuard. No se realizo ninguna solicitud.') from exc


class TunnelHTTPHandler(HTTPHandler):
    def __init__(self, tunnel, target_url, target_ip):
        super().__init__()
        self.tunnel = tunnel
        self.target_url = target_url
        self.target_ip = target_ip

    def http_open(self, req):
        if req.full_url != self.target_url:
            raise OSError('URL fuera del alcance permitido.')
        tunnel, target_ip = self.tunnel, self.target_ip

        class Connection(http.client.HTTPConnection):
            def connect(self):
                if self.host != target_ip or self.port != 80 or self._tunnel_host:
                    raise OSError('Destino fuera del alcance permitido.')
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                try:
                    sock.settimeout(self.timeout)
                    # Windows IP_UNICAST_IF: el indice se entrega en orden de red.
                    sock.setsockopt(socket.IPPROTO_IP, 31, struct.pack('!I', tunnel.index))
                    sock.bind((tunnel.ip, 0))
                    sock.connect((target_ip, 80))
                    if sock.getsockname()[0] != tunnel.ip:
                        raise OSError('Origen distinto al tunel. Conexion bloqueada.')
                    self.sock = sock
                except BaseException:
                    sock.close()
                    raise

        return self.do_open(Connection, req)


def vpn_opener(target_url, target_ip, redirect_handler):
    # Se comprueba en cada ejecucion manual, sin conexiones de prueba.
    tunnel = read_tunnel()
    return build_opener(ProxyHandler({}), redirect_handler,
                        TunnelHTTPHandler(tunnel, target_url, target_ip)), tunnel
