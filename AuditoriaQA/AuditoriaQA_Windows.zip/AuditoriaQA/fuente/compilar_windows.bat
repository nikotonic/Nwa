@echo off
setlocal
cd /d "%~dp0"
py -3 -m venv .venv
if errorlevel 1 goto error
.venv\Scripts\python.exe -m pip install pyinstaller==6.22.3
if errorlevel 1 goto error
.venv\Scripts\python.exe -m PyInstaller --clean --noconfirm --onefile --windowed --name AuditoriaQA app_windows.py
if errorlevel 1 goto error
echo Listo: dist\AuditoriaQA.exe
pause
exit /b 0
:error
echo No se pudo compilar. Revisa el mensaje anterior.
pause
exit /b 1
